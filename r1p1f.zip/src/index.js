import React from "react";
import ReactDOM from "react-dom";
import Cardss from './Cards';
ReactDOM.render(
  <>
   <Cardss imgsrc="https://images.pexels.com/photos/2011367/pexels-photo-2011367.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" 
   title="A Netflix Oringinal"
      sname="Dark"
      link="https://www.pexels.com/" />
   
   <Cardss imgsrc="https://images.pexels.com/photos/10057617/pexels-photo-10057617.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
    title="boombaam"
    sname= "park"
    link="https://www.pexels.com/"/>

   <Cardss imgsrc="https://images.pexels.com/photos/9336604/pexels-photo-9336604.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
     title="loombaam"
     sname= "cpark"
     link="https://www.pexels.com/"
     />
   
  
   </>,
   
  

 document.getElementById("root")
 );
 