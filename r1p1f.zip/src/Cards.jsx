import React from 'react';
function Cardss(props){
  return(
    <>
    <div className="cards">
      <div className="card">
        <img src={props.imgsrc} alt="my_pic" />
  
  <div className="card_info">
    <span className="cards_user">{props.title}</span>
    <br/>
    <a href={props.link} target="_blank"></a>
    <button>Watch Now </button>
    
    
    </div>
  
    </div>
    </div>
  
      < />

  )
}
export default Cardss;